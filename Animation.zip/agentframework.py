import random

class Agent():
    
    def __init__(self, i, y, x, environment, agents):
        self.environment = environment
        self.store = 0
        self.agents = agents
        #self.y = random.randint(0, 99)
        #self.x = random.randint(0, 99)
        self.y = y
        self.x = x
        self.i = i
        
    def __str__(self):
        return "Agent" + str(self.i) + ", y=" + str(self.y) + ", x=" + str(self.x) + ", store=" + str(self.store) 
       
    def move(self):
        #print("Before move", self) # Test movement.
        if (random.random() < 0.5):
            self.y = (self.y + 1) % 100
        else:
            self.y = (self.y - 1) % 100
        if (random.random() < 0.5):
            self.x = (self.x + 1) % 100
        else:
            self.x = (self.x - 1) % 100
        #print("After move", self) # Test movement.
            
    def eat(self): # can you make it eat what is left?
        #print("Before eat", self) # Test eat
        if self.environment[self.y][self.x] > 10:
            self.environment[self.y][self.x] -= 10
            self.store += 10
        #print("After eat", self) # Test eat
        
    def share_with_neighbours(self, neighbourhood):
        for i in range(len(self.agents)):
            d = self.distance_between(self.agents[i])
            if (d < neighbourhood):
                print(self, "sharing with", self.agents[i])
                ave = (self.store + self.agents[i].store) / 2
                self.store = ave
                self.agents[i].store = ave
            else:
                print(self, "not sharing with", self.agents[i])
            
    def distance_between(self, b):
        """
        Calculate the distance between self, b.
    
        Parameters
        ----------
        self : Agent
            This is a goat on a haystack.
        b : Agent
            This is a goat on a haystack.
    
        Returns
        -------
        Number
            Euclidean distance in a 2D space between a and b.
        """
        return (((self.x - b.x)**2) + ((self.y - b.y)**2))**0.5