import csv
import matplotlib.pyplot

environment = []
with open('in.txt', newline='') as f:
    reader = csv.reader(f, quoting=csv.QUOTE_NONNUMERIC)
    for row in reader:
        rowlist = []
        environment.append(rowlist)
        for value in row:
            rowlist.append(value)


print(environment)         
            

matplotlib.pyplot.imshow(environment)
matplotlib.pyplot.show()